import pandas as pd
import matplotlib.pyplot as plt

def generate_report(filename="sales_data.csv"):
    try:
        # Read CSV or Excel
        if filename.endswith(".csv"):
            data = pd.read_csv(filename)
        elif filename.endswith(".xlsx"):
            data = pd.read_excel(filename)
        else:
            raise ValueError("Unsupported file format. Use CSV or XLSX.")

        # Calculate revenue
        data["Revenue"] = data["Units Sold"] * data["Unit Price"]

        # Group by product
        summary = data.groupby("Product")["Revenue"].sum().reset_index()

        # Total revenue
        total_revenue = summary["Revenue"].sum()

        # Top product
        top_product = summary.loc[summary["Revenue"].idxmax()]

        # Write to report.txt
        with open("report.txt", "w", encoding="utf-8") as f:
            f.write("📊 Sales Summary\n")
            for _, row in summary.iterrows():
                f.write(f"Product: {row['Product']} – Revenue: {row['Revenue']}\n")
            f.write(f"\n🔸 Total Revenue: {total_revenue}\n")
            f.write(f"🔸 Top Product: {top_product['Product']}\n")

        # Create bar chart
        plt.figure(figsize=(6,4))
        plt.bar(summary["Product"], summary["Revenue"])
        plt.xlabel("Product")
        plt.ylabel("Revenue")
        plt.title("Revenue by Product")
        plt.savefig("sales_chart.png")
        plt.close()

        print("Report generated successfully!")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    generate_report("sales_data.csv")
