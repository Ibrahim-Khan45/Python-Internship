import argparse
import json
import os
from colorama import Fore, Style, init

init(autoreset=True)
TASKS_FILE = "tasks.json"

def load_tasks():
    if not os.path.exists(TASKS_FILE):
        return []
    with open(TASKS_FILE, "r") as f:
        return json.load(f)

def save_tasks(tasks):
    with open(TASKS_FILE, "w") as f:
        json.dump(tasks, f, indent=4)

def add_task(description):
    tasks = load_tasks()
    tasks.append({"description": description})
    save_tasks(tasks)
    print(Fore.GREEN + "Task added successfully.")

def list_tasks():
    tasks = load_tasks()
    if not tasks:
        print(Fore.YELLOW + "No tasks found.")
        return
    print(Fore.CYAN + "Your Tasks:")
    for idx, task in enumerate(tasks, 1):
        print(Fore.CYAN + f"{idx}. {task['description']}")

def delete_task(index):
    tasks = load_tasks()
    if 0 < index <= len(tasks):
        removed = tasks.pop(index - 1)
        save_tasks(tasks)
        print(Fore.RED + f"Deleted task: {removed['description']}")
    else:
        print(Fore.RED + "Invalid task index.")

def export_tasks():
    tasks = load_tasks()
    with open("tasks_export.txt", "w") as f:
        for idx, task in enumerate(tasks, 1):
            f.write(f"{idx}. {task['description']}\n")
    print(Fore.MAGENTA + "Tasks exported to tasks_export.txt")

def main():
    parser = argparse.ArgumentParser(description="📝 To-Do List Manager CLI Tool")
    subparsers = parser.add_subparsers(dest="command")

    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("description", help="Task description")

    subparsers.add_parser("list", help="List all tasks")

    delete_parser = subparsers.add_parser("delete", help="Delete a task by index")
    delete_parser.add_argument("index", type=int, help="Task index to delete")

    subparsers.add_parser("export", help="Export tasks to a .txt file")

    args = parser.parse_args()

    if args.command == "add":
        add_task(args.description)
    elif args.command == "list":
        list_tasks()
    elif args.command == "delete":
        delete_task(args.index)
    elif args.command == "export":
        export_tasks()
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
