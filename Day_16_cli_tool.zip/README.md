# 📝 To-Do List Manager CLI Tool

This is a simple command-line To-Do List Manager built with Python using `argparse` and `colorama`.

## 🚀 Features
- Add tasks
- View all tasks
- Delete tasks by index
- Export tasks to a `.txt` file
- Colored terminal output

## 🛠️ Usage

Install dependencies:
```bash
pip install colorama
```

Run the CLI tool:
```bash
# Add a task
python cli_tool.py add "Finish Python project"

# View tasks
python cli_tool.py list

# Delete a task
python cli_tool.py delete 1

# Export tasks
python cli_tool.py export
```

## 📁 Files
- `cli_tool.py` – Main Python script
- `tasks.json` – Tasks storage (auto-created)
- `tasks_export.txt` – Exported list

## 📢 Share It
Post a screenshot of your CLI tool on LinkedIn with hashtag:
```
#ProSensiaInternship
```
