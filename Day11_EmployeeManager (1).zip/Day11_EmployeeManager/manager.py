from employee import Employee

class EmployeeManager:
    def __init__(self, filepath="employee_data.txt"):
        self.filepath = filepath
        self.employees = []
        self.load_from_file()

    def load_from_file(self):
        try:
            with open(self.filepath, "r") as file:
                for line in file:
                    self.employees.append(Employee.from_line(line))
        except FileNotFoundError:
            open(self.filepath, "w").close()

    def save_to_file(self):
        with open(self.filepath, "w") as file:
            for emp in self.employees:
                file.write(emp.to_line())

    def add_employee(self, name, department, salary, joining_year):
        self.employees.append(Employee(name, department, salary, joining_year))
        print("Employee added successfully!")

    def list_employees(self):
        for emp in self.employees:
            emp.display()

    def search_employee(self, term):
        results = list(filter(lambda e: term.lower() in e.name.lower() or term.lower() in e.department.lower(), self.employees))
        for emp in results:
            emp.display()

    def sort_by_salary(self, desc=False):
        sorted_emps = sorted(self.employees, key=lambda e: e.salary, reverse=desc)
        for emp in sorted_emps:
            emp.display()

    def generate_report(self, report_file="employee_report.txt"):
        total = len(self.employees)
        avg_salary = sum(emp.salary for emp in self.employees) / total if total else 0
        with open(report_file, "w") as f:
            f.write(f"Total Employees: {total}\n")
            f.write(f"Average Salary: {avg_salary:.2f}\n")
        print(f"Report written to {report_file}")