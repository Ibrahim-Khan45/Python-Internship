# Day11_EmployeeManager

## Features
- OOP design with Employee & Manager classes
- File handling (save/load)
- Search & Sort using lambda
- Summary report generation
- CLI Menu Interface

## How to Run
```bash
python main.py
```

## Files
- `employee.py` – Employee class
- `manager.py` – Handles employee list & file I/O
- `utils.py` – Input validation helpers
- `employee_data.txt` – Persistent storage
- `employee_report.txt` – Generated report