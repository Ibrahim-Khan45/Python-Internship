import json

# Module: status_tracker
def create_feature_status(features):
    return {feature: "pending" for feature in features}

# Function to parse the client requirements from the file
def parse_client_requirements(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()

    project, timeline, priority = '', '', ''
    features = []

    for line in lines:
        line = line.strip()
        if line.startswith("Project:"):
            project = line.split(":", 1)[1].strip()
        elif line.startswith("Timeline:"):
            timeline = line.split(":", 1)[1].strip()
        elif line.startswith("Priority:"):
            priority = line.split(":", 1)[1].strip()
        elif line.startswith("- "):
            features.append(line[2:].strip())

    return {
        "Project": project,
        "Timeline": timeline,
        "Priority": priority,
        "Features": features
    }

# Function to generate output files
def generate_output(parsed_data):
    summary_text = (
        "📘 Project Summary Report\n"
        "-------------------------\n"
        f"Project: {parsed_data['Project']}\n"
        f"Timeline: {parsed_data['Timeline']}\n"
        f"Priority: {parsed_data['Priority']}\n"
        "Features to Implement:\n"
    )
    for feature in parsed_data['Features']:
        summary_text += f" - {feature}\n"

    # Save to .txt file
    with open("project_summary.txt", "w") as txt_file:
        txt_file.write(summary_text)

    # Save to .json file (bonus)
    feature_status = create_feature_status(parsed_data['Features'])
    json_data = {
        "Project": parsed_data['Project'],
        "Timeline": parsed_data['Timeline'],
        "Priority": parsed_data['Priority'],
        "Features": feature_status
    }

    with open("project_summary.json", "w") as json_file:
        json.dump(json_data, json_file, indent=4)

# Main execution
if __name__ == "__main__":
    data = parse_client_requirements("client_requirements.txt")
    generate_output(data)
    print("✅ Project summary generated: project_summary.txt and project_summary.json")
