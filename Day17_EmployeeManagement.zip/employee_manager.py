import logging

# Configure logging
logging.basicConfig(filename="error_log.txt", level=logging.ERROR,
                    format="%(asctime)s - %(levelname)s - %(message)s")

class EmployeeNotFoundError(Exception):
    """Custom exception for missing employees"""
    pass

class EmployeeManager:
    def __init__(self):
        self.employees = {}

    def add_employee(self, emp_id, name, role):
        try:
            if emp_id in self.employees:
                raise ValueError("Employee ID already exists!")
            self.employees[emp_id] = {"name": name, "role": role}
        except Exception as e:
            logging.error(f"Error in add_employee: {e}")
            raise

    def get_employee(self, emp_id):
        try:
            if emp_id not in self.employees:
                raise EmployeeNotFoundError("Employee not found!")
            return self.employees[emp_id]
        except Exception as e:
            logging.error(f"Error in get_employee: {e}")
            raise

    def remove_employee(self, emp_id):
        try:
            if emp_id not in self.employees:
                raise EmployeeNotFoundError("Cannot remove, employee not found!")
            del self.employees[emp_id]
        except Exception as e:
            logging.error(f"Error in remove_employee: {e}")
            raise

if __name__ == "__main__":
    manager = EmployeeManager()
    try:
        manager.add_employee(1, "Alice", "Engineer")
        print(manager.get_employee(1))
        manager.remove_employee(2)  # Will trigger custom exception
    except Exception as e:
        print(f"Error occurred: {e}")
