import unittest
from employee_manager import EmployeeManager, EmployeeNotFoundError

class TestEmployeeManager(unittest.TestCase):

    def setUp(self):
        self.manager = EmployeeManager()

    def test_add_employee(self):
        self.manager.add_employee(1, "Alice", "Engineer")
        self.assertEqual(self.manager.get_employee(1)["name"], "Alice")

    def test_duplicate_employee(self):
        self.manager.add_employee(1, "Alice", "Engineer")
        with self.assertRaises(ValueError):
            self.manager.add_employee(1, "Bob", "Manager")

    def test_get_nonexistent_employee(self):
        with self.assertRaises(EmployeeNotFoundError):
            self.manager.get_employee(99)

    def test_remove_employee(self):
        self.manager.add_employee(1, "Alice", "Engineer")
        self.manager.remove_employee(1)
        with self.assertRaises(EmployeeNotFoundError):
            self.manager.get_employee(1)

if __name__ == "__main__":
    unittest.main()
