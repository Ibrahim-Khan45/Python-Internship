
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

os.makedirs('plots', exist_ok=True)

df = pd.read_csv('sales.csv')
df.dropna(inplace=True)

def save_plot(fig, filename):
    fig.savefig(f'plots/{filename}', bbox_inches='tight')
    plt.close(fig)

def plot_line_chart():
    monthly_revenue = df.groupby('Month')['Revenue'].sum()
    fig, ax = plt.subplots()
    monthly_revenue.plot(kind='line', marker='o', ax=ax)
    ax.set_title('Monthly Revenue')
    ax.set_xlabel('Month')
    ax.set_ylabel('Revenue')
    save_plot(fig, 'Line_Chart.png')

def plot_bar_chart():
    product_sales = df.groupby('Product')['Units_Sold'].sum()
    fig, ax = plt.subplots()
    product_sales.plot(kind='bar', color='skyblue', ax=ax)
    ax.set_title('Product Sales')
    ax.set_xlabel('Product')
    ax.set_ylabel('Units Sold')
    save_plot(fig, 'Bar_Chart.png')

def plot_pie_chart():
    market_share = df.groupby('Region')['Revenue'].sum()
    fig, ax = plt.subplots()
    market_share.plot(kind='pie', autopct='%1.1f%%', ax=ax)
    ax.set_ylabel('')
    ax.set_title('Market Share by Region')
    save_plot(fig, 'Pie_Chart.png')

def plot_heatmap():
    corr = df.select_dtypes(include='number').corr()
    fig, ax = plt.subplots()
    sns.heatmap(corr, annot=True, cmap='coolwarm', ax=ax)
    ax.set_title('Correlation Heatmap')
    save_plot(fig, 'Heatmap.png')

plot_line_chart()
plot_bar_chart()
plot_pie_chart()
plot_heatmap()

with open('Summary_Report.txt', 'w') as f:
    f.write("Charts Generated:\n")
    f.write("- Line_Chart.png: Monthly Revenue\n")
    f.write("- Bar_Chart.png: Product Sales\n")
    f.write("- Pie_Chart.png: Market Share by Region\n")
    f.write("- Heatmap.png: Correlation between Numeric Features\n")
    f.write("\nData Preview:\n")
    f.write(df.head().to_string())
