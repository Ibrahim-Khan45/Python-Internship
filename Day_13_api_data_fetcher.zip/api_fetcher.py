
import requests
import json

def fetch_json_data(url):
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"⚠️ Error fetching data: {e}")
        return None

def generate_btc_report(data):
    try:
        bpi = data["bpi"]
        report_lines = ["📊 Bitcoin Price Report", "--------------------------"]
        for currency, details in bpi.items():
            line = f"{currency}: {details['symbol']}{float(details['rate_float']):,.2f}"
            report_lines.append(line)
        return "\n".join(report_lines)
    except (KeyError, TypeError) as e:
        return f"⚠️ Error processing BTC data: {e}"

def save_report(filename, content):
    with open(filename, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"✅ Report saved to {filename}")

def filter_json(data, keyword):
    if not keyword:
        return json.dumps(data, indent=2)
    filtered = {}
    def recurse_filter(d):
        if isinstance(d, dict):
            return {k: recurse_filter(v) for k, v in d.items() if keyword.lower() in k.lower()}
        elif isinstance(d, list):
            return [recurse_filter(i) for i in d]
        else:
            return d
    filtered = recurse_filter(data)
    return json.dumps(filtered, indent=2)

def main():
    print("🔗 Default API: https://api.coindesk.com/v1/bpi/currentprice.json")
    url = input("🌐 Enter API URL (or press Enter to use default): ").strip()
    if not url:
        url = "https://api.coindesk.com/v1/bpi/currentprice.json"

    data = fetch_json_data(url)
    if data is None:
        return

    # Special handling for BTC API
    if "coindesk" in url:
        report = generate_btc_report(data)
        print("\n" + report)
        save_report("btc_price_report.txt", report)
    else:
        print("🔍 You can filter the JSON output by a keyword.")
        keyword = input("Enter a keyword to filter (or press Enter to skip): ").strip()
        filtered_json = filter_json(data, keyword)
        print("\n📦 Filtered JSON Output:\n")
        print(filtered_json)

if __name__ == "__main__":
    main()
